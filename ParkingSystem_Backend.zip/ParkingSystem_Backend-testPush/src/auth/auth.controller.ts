import { BadRequestException, Body, Controller, Post } from '@nestjs/common';
import { AuthService } from './auth.service';
import { SignupDto } from '../dtos/signup.dto';
import { LoginGoogleDto } from 'src/dtos/loginGoogle.dto';

@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) { }

  @Post('signup')
  async signUp(@Body() signUpData: SignupDto) {
    return this.authService.signUp(signUpData);
  }

  @Post('signup-admin')
  async signUpAdmin(@Body() signUpData: SignupDto) {
    return this.authService.signUpAdmin(signUpData);
  }

  @Post('login')
  async login(@Body() body: { idToken: string }) {
    const { idToken } = body;
    if (!idToken) {
      throw new BadRequestException('Thiếu idToken');
    }
    return this.authService.loginWithFirebaseToken(idToken);
  }

  @Post('login-google')
  async loginGoogle(@Body() loginGoogleData: LoginGoogleDto) {
    return this.authService.loginGoogle(loginGoogleData);
  }

  // // Gửi OTP qua email
  // @Post('request-otp')
  // async requestOtp(@Body('email') email: string) {
  //   if (!email) {
  //     throw new BadRequestException('Email không được để trống');
  //   }

  //   const otp = await this.authService.requestOTP(email);

  //   return { message: 'OTP đã được gửi đến email', otp };
  // }

  // @Post('request-otp-signup')
  // async requestOtpForSignUp(@Body('email') email: string) {
  //   if (!email) {
  //     throw new BadRequestException('Email không được để trống');
  //   }

  //   const otp = await this.authService.requestOtpSignup(email);

  //   return { message: 'OTP đã được gửi đến email', otp };
  // }

  // // Xác minh OTP
  // @Post('verify-otp')
  // async verifyOtp(
  //   @Body('email') email: string,
  //   @Body('otp') otp: string,
  // ) {
  //   if (!email || !otp) {
  //     throw new BadRequestException('Email và OTP là bắt buộc');
  //   }

  //   const isValid = await this.authService.verifyOTP(email, otp);

  //   if (!isValid) {
  //     throw new BadRequestException('OTP không hợp lệ hoặc đã hết hạn');
  //   }

  //   return { message: 'Xác minh OTP thành công' };
  // }

  // @Post('reset-password')
  // async resetPassword(
  //   @Body('email') email: string,
  //   @Body('newPassword') newPassword: string
  // ) {
  //   // Cập nhật mật khẩu mới (hash trước khi lưu)
  //   await this.authService.resetPassword(email, newPassword);

  //   return { message: 'Mật khẩu đã được cập nhật thành công' };
  // }

  // @Post('generate-token')
  // async generateTokenGoogle(@Body() { email }: { email: string, }) {
  //   return this.authService.generateGoogleTokens(email);

  // }
}
