import { Module } from '@nestjs/common';
import { AdminService } from './admin.service';
import { AdminController } from './admin.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { Admin, AdminSchema } from 'src/schemas/admin.schema';
import { Doctor, DoctorSchema } from 'src/schemas/doctor.schema';
import { CloudinaryModule } from 'src/cloudinary/cloudinary.module';
import { FirebaseService } from 'src/firebase/firebase.service';

@Module({

  imports: [CloudinaryModule,
    MongooseModule.forFeature([
      {
        name: Admin.name,
        schema: AdminSchema,
      },
      {
        name: Doctor.name,
        schema: DoctorSchema,
      }
    ]),
  ],
  controllers: [AdminController],
  providers: [AdminService, FirebaseService],
})
export class AdminModule { }
